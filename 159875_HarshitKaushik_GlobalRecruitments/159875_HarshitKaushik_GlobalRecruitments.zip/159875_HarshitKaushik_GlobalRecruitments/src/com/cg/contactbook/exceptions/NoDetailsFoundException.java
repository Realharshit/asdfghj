package com.cg.contactbook.exceptions;

public class NoDetailsFoundException extends Exception {

	public NoDetailsFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoDetailsFoundException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoDetailsFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoDetailsFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoDetailsFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
